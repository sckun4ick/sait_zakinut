fetch('http://localhost:3003/api/main')
    .then(res => res.json())
    .then(data => {
        document.getElementById('result').innerHTML = data.map(row => `
            <p>ID: ${row.id}</p>
            <p>Name: ${row.name}</p>
            <p>Number: ${row.phone}</p>
            <hr>
            `).join('')
    })
    .catch(err => {
        document.getElementById('result').innerHTML = `<p style="color: red;">Eror: ${err.message}</p>`
    })

function sendData(){
    fetch ('http://localhost:3003/api/main', {
        method: "POST",
        headers: { 'Content-Type': 'application/json'},
        body: JSON.stringify({
            name: document.getElementById('name').value,
            phone: document.getElementById('phone').value
    })
    })
    .then(res => res.json())
    .then(data => console.log('Answer:', data))
    .catch(err => console.error('Error:', err))
}