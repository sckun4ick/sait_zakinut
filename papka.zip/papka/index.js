const express = require("express")
const app = express()
const {Pool} = require("pg")
const cors = require('cors')
const PORT = 3003

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "postgres",
    password: "1234",
    port: "5432"
})

app.get('/api/main', async (req, res) =>{
    try{
        const result = await pool.query('SELECT * FROM test_table1')
        res.json(result.rows)
    } catch (error) {
        res.status(500).json({error: `Server error : ${error.message}`})
    }
})

app.listen(PORT, () => {
    console.log(`Сервер запущен на ${PORT}`)
})